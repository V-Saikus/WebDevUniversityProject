import React, {createElement} from 'react';
import ReactDOM from "react-dom";
import App from './App';
import RenderLogin, {Work} from './login';
import axios from "axios";
import RenderSignup, {WorkSignUp} from './sign_up';
import Menu from "./audiences";

jest.mock('axios');

describe('App', () => {
  it('alive',()=>{
    const div = document.createElement("div");
    ReactDOM.render(<App/>,div)
  })
});

class Checklogin {
    static work() {
        return Work();
    }
}

describe('login',()=>{
    it('success axios',()=>{
        axios.post.mockResolvedValueOnce({data:{username:'k',password:'k'}});
        Checklogin.work().then(data => expect(data).toEqual("Success"));
    })
    it('error axios',()=>{
        axios.post.mockResolvedValueOnce({data:{username:'mark',password:'1234'}});
        Checklogin.work().then(data => expect(data).toEqual("Error"));
    })
    it('renders',()=>{
        const div = document.createElement("div");
        ReactDOM.render(<RenderLogin/>,div)

    })
});

class Checksignup {
    static work() {
        return WorkSignUp();
    }
}

describe('sign_up',()=>{
    it('renders',()=>{
        const div = document.createElement("div");
        ReactDOM.render(<RenderSignup/>,div)
    })
    it('success axios',()=>{
        axios.post.mockResolvedValueOnce({data:{f:'k',s:'k',b:'k',e:'k@k',p:'k'}});
        Checksignup.work().then(data => expect(data).toEqual("Success"));
    })
    it('error axios',()=>{
        axios.post.mockResolvedValueOnce({data:{f:'k',s:'k',b:'',e:'k@k',p:'k'}});
        Checksignup.work().then(data => expect(data).toEqual("Success"));
    })
})

describe('Menu', function () {
    it('renders',()=>{
        const div = document.createElement("div");
        ReactDOM.render(<Menu>{true}</Menu>,div)
    })
    it('gets events',()=>{
        const div = document.createElement("div");
        ReactDOM.render(<Menu>{true}</Menu>,div);
        var t =document.getElementById('test_id');
        if (t)
            t.dispatchEvent('onClick');
    })
});


