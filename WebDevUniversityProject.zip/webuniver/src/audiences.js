import React from 'react';
import './css/audiences.css';
import RenderLogOut from "./js/logistics";
import user_img from './img/user.svg';
import aud_img from './img/image.png';
import {CheckPassword, ShowManageAccount,ChangeData,check,AddFriend,ShowDeleteAccount} from './js/functions';
// import {start,func,Display,ShowAddEvent,AddEvent,ShowUpdateEvent,UpdateEvent,moveDate,ShowShareEvent,ShareEvent,DeleteEvent,ShowDeleteEvent} from "./calendar_functions";
import {ReactSession} from 'react-client-session';
function RenderMenu()
{
    if (!ReactSession.get('id'))
        return (
            <h1 style={{textAlign:'center', marginTop:200}}>Return to login</h1>
        );
    return (
        <div className='AudiencesForm'>
            <nav className="navbar">
                <ul className="navbar-nav">
                    {/*<li className="nav-item">*/}
                    {/*    <a href="/profile" className="nav-link">*/}
                    {/*        <img className="svg" src={user_img}/>*/}
                    {/*    </a>*/}
                    {/*</li>*/}
                    <RenderLogOut/>
                </ul>
            </nav>
            <div id="background">
                <div id="info_box">
                    <div>
                        <form className="audience" method="get">
                            <img className="audience_img" src={aud_img}/>
                                <div className="info">
                                    <div id="audience_name">audience_var</div>
                                </div>
                        </form>
                    </div>
                    <div>
                        <form className="audience" method="get">
                            <img className="audience_img" src={aud_img}/>
                                <div className="info">
                                    <div id="audience_name">audience_var</div>
                                </div>
                        </form>
                    </div>
                    <div>
                        <form className="audience" method="get">
                            <img className="audience_img" src={aud_img}/>
                                <div className="info">
                                    <div id="audience_name">audience_var</div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}


export default RenderMenu;