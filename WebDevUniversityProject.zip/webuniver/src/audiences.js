import React from 'react';
import './css/audiences.css';
import plus_img from './img/plus.svg';
import aud_img from './img/image.png';
// import {CheckPassword, ShowManageAccount,ChangeData,check,AddFriend,ShowDeleteAccount} from './js/functions';
// import {start,func,Display,ShowAddAudience,AddAudience,ShowUpdateEvent,UpdateEvent,moveDate,ShowShareEvent,ShareEvent,DeleteEvent,ShowDeleteEvent} from "./calendar_functions";
import RenderLogout from "./js/functions";
import {ShowAddAudience,AddAudience,ShowAudience,ShowAddReservation,AddReservation} from "./js/functions";
import {ReactSession} from 'react-client-session';

function RenderMenu()
{
    if (!ReactSession.get('id'))
        return (
            <h1 style={{textAlign:'center', marginTop:200}}>Return to login</h1>
        );
    return (
        <div className='AudiencesForm'>
            <div id="background">
                <nav className="navbar">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <a onClick={ShowAddAudience} className="nav-link">
                                <img className="svg" src={plus_img}/>
                            </a>
                        </li>
                        <RenderLogout/>
                    </ul>
                </nav>
                <div id="info_box">
                    <div>
                        <button id="2" onClick={ShowAudience} className="audience">
                            <img className="audience_img" src={aud_img}/>
                            <div className="info">
                                <div id="2">audience_var</div>
                            </div>
                        </button>
                    </div>
                    <dib>
                        <button id="3" onClick={ShowAudience} className="audience">
                            <img className="audience_img" src={aud_img}/>
                            <div className="info">
                                <div id="2">audience_var</div>
                            </div>
                        </button>
                    </dib>
                </div>
            </div>
            <div className="popups">
                <div id="back" style={{display:'none'}}/>
                <div id="add_audience" className="popup_box" style={{display:'none'}}>
                    <div className="content">
                        <h1 id="mes_add">Create new Audience</h1>
                        <form>
                            <div className="data">
                                <input type="text" id="name" placeholder=" " required/>
                                <span/>
                                <label>Name</label>
                            </div>
                            <div className="data">
                                <input type="number" id="price_per_hour" placeholder=" "/>
                                <span/>
                                <label>Price per hour</label>
                            </div>
                            <input type="submit" onClick={AddAudience} value="Add"/>
                        </form>
                        <form>
                            <button onClick={ShowAddAudience} className="exit">Cancel</button>
                        </form>
                    </div>
                </div>
                <div id="add_reservation" className="popup_box" style={{display:'none'}}>
                    <div className="content">
                        <h1 id="mes_add">Create new Reservation</h1>
                        <form>
                            <label id="audience_name"><a>Audience name</a></label>
                            <label id="price"><a>Audience price</a></label>
                            <label id="audience_id" style={{display:'none'}}><a>Audience price</a></label>
                            <div className="data">
                                <input type="date" id="start" placeholder=" "/>
                                <span/>
                                <label>From:</label>
                            </div>
                            <div className="data">
                                <input type="date" id="end" placeholder=" "/>
                                <span/>
                                <label>To:</label>
                            </div>
                            <input type="submit" onClick={AddReservation} value="Add"/>
                        </form>
                        <form>
                            <button onClick={ShowAddReservation} className="exit">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default RenderMenu;