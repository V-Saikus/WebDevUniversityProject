import React from 'react';
import axios from "axios";
import './css/sign_up.css';
import {useHistory} from "react-router-dom";


function RenderSignup()
{
    const history = useHistory();
    function Func(event) {
        event.preventDefault();
        var first_name = document.getElementById('first_name').value;
        var second_name = document.getElementById('second_name').value;
        var birthday = document.getElementById('birthday').value;
        var password = document.getElementById('password').value;
        var email = document.getElementById('email').value;
        var phone_number = document.getElementById('phone_number').value;
        const formData = new FormData();
        formData.append(
            'myFile',
            this.state.selectedFile,
            this.state.selectedFile.name
        )
        var file = document.getElementById('file').value;
        axios.post('http://localhost:5000/sign_up',
            {
                first_name:first_name,
                second_name:second_name,
                birthday:birthday,
                email:email,
                phone_number:phone_number,
                password:password,
                file:file
            })
            .then(resp => {
                if (resp.data.message === 'Success') {
                    history.push('/') ;
                }
                else
                {
                    document.getElementById("message").innerHTML =
                        '<h1 style="color:blueviolet;">'+resp.data.message+'</h1>';
                }
            });

    }
    return (
        <div className='SignupForm'>
            <div className="center">
                <div id="message"><h1>Register</h1></div>
                <form onSubmit={Func}>
                    <div className="input_field">
                        <label>First name</label>
                        <input type="text" id="first_name" placeholder=" " required/>
                        <span/>
                    </div>
                    <div className="input_field">
                        <label>Second name</label>
                        <input type="text" id="second_name" placeholder=" " required/>
                        <span/>
                    </div>
                    <div className="input_field">
                        <label>Birthday</label>
                        <input type="date" id="birthday" placeholder=" " required/>
                        <span/>
                    </div>
                    <div className="input_field">
                        <label>Phone Number</label>
                        <input type="tel" id="phone_number" placeholder=" " required/>
                        <span/>
                    </div>
                    <div className="input_field">
                        <label>Email</label>
                        <input type="email" id="email" placeholder=" " required/>
                        <span/>
                    </div>
                    <div className="input_field">
                        <label>Password</label>
                        <input type="password" id="password" placeholder=" " required/>
                        <span/>
                    </div>
                    <input type="submit" value="Signup"/>
                </form>
            </div>
        </div>
    );
}

export default  RenderSignup;