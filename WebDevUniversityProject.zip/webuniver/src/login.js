import React from 'react';
import axios from "axios";
import './css/login.css';
import {ReactSession} from 'react-client-session';
import {useHistory,Link} from "react-router-dom";

ReactSession.setStoreType("localStorage");
function RenderLogin()
{
    const history = useHistory();
    function Func(event) {
        event.preventDefault();
        var phone_number = document.getElementById('phone_number').value;
        var password = document.getElementById('password').value;
        axios.post('http://localhost:5000/login',
            {
                phone_number: phone_number,
                password: password
            })
            .then(resp => {
                if (resp.data.message === 'Success') {
                    ReactSession.set('id',resp.data.id);
                    ReactSession.set('role',resp.data.role);
                    ReactSession.set('username',resp.data.email);
                    history.push('/audiences') ;
                }
                else
                {
                    document.getElementById("login").innerHTML =
                        '<h1 style="color:blueviolet;">'+resp.data.message+'</h1>';
                }
            });

    }
    return (
        <div className='LoginForm'>
            <div className="center">
                <div id="message"><h1>Login</h1></div>
                <form onSubmit={Func} method="post">
                    <div className="txt_field">
                        <input type="tel" id="phone_number" required/>
                        <span/>
                        <label>Phone Number</label>
                    </div>
                    <div className="txt_field">
                        <input type="password" id="password" required/>
                        <span/>
                        <label>Password</label>
                    </div>
                    <input type="submit" value="Login"/>
                    <div className="signup_link">
                        First time? <Link to="/sign_up">Signup</Link>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default  RenderLogin;