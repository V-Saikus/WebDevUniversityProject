import {useHistory} from "react-router-dom";
import {ReactSession} from "react-client-session";
import React from "react";
import exit_img from '../img/sign-out.svg';

function RenderLogout()
{
    const history = useHistory();
    function log_out(event)
    {
        event.preventDefault();
        ReactSession.set('id',null);
        history.push('/');
    }
    return (
        <li className="nav-item">
            <a onClick={log_out} className="nav-link">
                <img className="svg" src={exit_img}/>
            </a>
        </li>
    );
}

export default RenderLogout;