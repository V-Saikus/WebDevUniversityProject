import {useHistory} from "react-router-dom";
import {ReactSession} from "react-client-session";
import React from "react";
import exit_img from '../img/sign-out.svg';
import axios from "axios";

function RenderLogout()
{
    const history = useHistory();
    function log_out(event)
    {
        event.preventDefault();
        ReactSession.set('id',null);
        history.push('/');
    }
    return (
        <li className="nav-item">
            <a onClick={log_out} className="nav-link">
                <img className="svg" src={exit_img}/>
            </a>
        </li>
    );
}

function DisplayPopup()
{
    const popup = document.getElementById('popups');
    if(popup.style.display === "block")
        popup.style.display = "none";
    else
        popup.style.display = "block";
}

function  Display(id)
{
    DisplayPopup();
    const popup = document.getElementById(id);
    if(popup.style.display==='none')
        popup.style.display='block';
    else
        popup.style.display='none';
}

function ShowAddAudience(event)
{
    event.preventDefault();
    Display('AddAudience');
    // document.getElementById("mes_add").innerHTML='<h1>Create new Event</h1>';
    // document.getElementById("name").value = "";
    // document.getElementById("time").value = "";
    // document.getElementById("desc").value = "";
    // document.getElementById("date_").value =current_day+'/'+(dt.getMonth()+1)+'/'+dt.getFullYear();
}

function AddAudience(event)
{
    event.preventDefault();
    var name = document.getElementById('name').value;
    var time = document.getElementById('time').value;
    var date = document.getElementById('date_').value;
    var desc = document.getElementById('desc').value;
    axios('http://localhost:5000/add_event',{
            method:'POST',
            credentials: "include",
            headers:{
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                withCredentials: true,
                mode: 'no-cors',
            },
            data: {
                name:name,
                time:time,
                date:date,
                desc:desc,
                id:ReactSession.get('id')
            }
        }
    )
        .then(resp => {
            if (resp.data.message==='Success') {
                ShowAddAudience(event);
            }
            else
            {
                document.getElementById("mes_add").innerHTML =
                    '<h1 style="color:blueviolet;">'+resp.data.message+'</h1>';
            }
        });
}
