import {useHistory} from "react-router-dom";
import {ReactSession} from "react-client-session";
import React from "react";
import exit_img from '../img/sign-out.svg';
import axios from "axios";
import '../css/audiences.css';
ReactSession.setStoreType("localStorage");


function RenderLogout()
{
    const history = useHistory();
    function log_out(event)
    {
        event.preventDefault();
        ReactSession.set('id',null);
        history.push('/');
    }
    return (
        <li className="nav-item">
            <a onClick={log_out} className="nav-link">
                <img className="svg" src={exit_img}/>
            </a>
        </li>
    );
}

function DisplayPopup()
{
    const popup = document.getElementById('back');
    if(popup.style.display === "block")
        popup.style.display = "none";
    else
        popup.style.display = "block";
}

function  Display(id)
{
    DisplayPopup();
    const popup = document.getElementById(id);
    if(popup.style.display==='none')
        popup.style.display='block';
    else
        popup.style.display='none';
}

function ShowAddAudience(event)
{
    event.preventDefault();
    Display('add_audience');
}

function AddAudience(event)
{
    event.preventDefault();
    var name = document.getElementById('name').value;
    var price_per_hour = document.getElementById('price_per_hour').value;
    axios('http://localhost:5000/audience',{
            method:'POST',
            credentials: "include",
            headers:{
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                withCredentials: true,
                mode: 'no-cors',
            },
            data: {
                name:name,
                price_per_hour:price_per_hour,
                id:ReactSession.get('id')
            }
        }
    )
        .then(resp => {
            if (resp.data.message==='Success') {
                ShowAddAudience(event);
            }
            else
            {
                document.getElementById("mes_add").innerHTML =
                    '<h1 style="color:blueviolet;">'+resp.data.message+'</h1>';
            }
        });
}


function ShowAudience(event)
{
    axios.get('http://localhost:5000/audience/1', {})
        .then(audience => {
            if (!audience.data.message){
                var tmp = document.getElementById('audience_name');
                var tmp1 = document.getElementById('price');
                var tmp2 = document.getElementById('audience_id');
                var temp = audience.data.audience;
                let arr="";
                ShowAddReservation(event);
                try {
                    arr ="<tr><td>"+temp['name']+"</td></tr>";
                    tmp.innerHTML=arr;
                    arr ="<tr><td>"+temp['price_per_hour']+"</td></tr>";
                    tmp1.innerHTML=arr;
                    arr ="<tr><td>"+1+"</td></tr>";
                    tmp2.innerHTML=arr;
                }
                catch(error) {
                    temp+="<tr><td>new event</td><td>hour</td><td>a few words</td></tr>";
                    tmp.innerHTML=temp;
                }
            }
        });
}

function ShowAddReservation(event)
{
    event.preventDefault();
    Display('add_reservation');
}

function AddReservation(event,id)
{
    event.preventDefault();
    var start_time = document.getElementById('start').value;
    var end_time = document.getElementById('end').value;
    axios('http://localhost:5000/audience/reserve',{
            method:'POST',
            credentials: "include",
            headers:{
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json',
                withCredentials: true,
                mode: 'no-cors',
            },
            data: {
                start_time:start_time,
                end_time:end_time,
                audience_id:1,
                user_id:ReactSession.get('id')
            }
        }
    )
        .then(resp => {
            if (resp.data.message==='Success') {
                ShowAddReservation(event);
            }
            else
            {
                document.getElementById("mes_add").innerHTML =
                    '<h1 style="color:blueviolet;">'+resp.data.message+'</h1>';
            }
        });
}



export {
    DisplayPopup,
    Display,
    ShowAddAudience,
    AddAudience,
    ShowAddReservation,
    AddReservation,
    ShowAudience
}

export default RenderLogout;
