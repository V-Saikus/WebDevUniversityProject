import {Component} from "react";
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
import RenderSignup from "./sign_up";
import RenderLogin from "./login";
import RenderAudiences from "./audiences";
// import RenderProfile from "./profile";


class App extends Component {
    render(){
        return(
            <Router>
                <div className={'Reservation'}>
                    <Switch>
                        <Route path='/' exact component={RenderLogin}/>
                        <Route path='/sign_up'  component={RenderSignup}/>
                        <Route path='/audiences'  component={RenderAudiences}/>
                    </Switch>
                </div>
            </Router>
        )}

}

export default App;
