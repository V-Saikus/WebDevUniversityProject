from models import *
from config import *


def get_serializable_audience(audience):
    result = {
        'id': audience.id,
        'name': audience.name,
        'price_per_hour': audience.price_per_hour,
        'user_id': audience.user_id,
    }

    return result


@app.route('/audience', methods=['POST'])
# @auth.login_required
def create_audience():
    if not request.is_json:
        return jsonify({'message': 'Missing JSON in request'})
    data = request.json
    name=data['name']
    price_per_hour=int(data['price_per_hour'])
    creator_id = int(data['id'])
    db.session.add(Audience(name=name, price_per_hour=price_per_hour, user_id=creator_id))
    db.session.commit()
    return jsonify({'message': 'Success'})

@app.route('/audience', methods=['GET'])
def get_audiences():
    audiences = Audience.query.all()
    if len(audiences) == 0:
        return jsonify({"message": "No audiences found"})
    else:
        return jsonify(audiences=[get_serializable_audience(var) for var in audiences])

@app.route('/audience/<audienceId>', methods=['GET'])
def get_audience(audienceId):
    try:
        int(audienceId)
    except ValueError:
        return jsonify({"message": "Invalid Id supplied"})
    audience=Audience.query.filter_by(id=audienceId).first()
    if not audience:
        return jsonify({"message": "Audience not found"})
    return jsonify(audience=get_serializable_audience(audience))


@app.route('/audience/<audienceId>', methods=['PUT'])
@auth.login_required
def put_audience(audienceId):
    audience = Audience.query.filter_by(id=audienceId).first()
    if audience is None:
        return jsonify({"Error": "audience not found"}), 404
    name = request.json.get('name', None)
    price_per_hour = request.json.get('price_per_hour', None)
    if not name and not price_per_hour:
        return jsonify(status='Invalid body supplied'), 404
    if name: audience.query.filter_by(id=audienceId).update(dict(name=name))
    if price_per_hour: audience.query.filter_by(id=audienceId).update(dict(price_per_hour=price_per_hour))
    db.session.commit()
    return jsonify(status='updated audience'), 202
